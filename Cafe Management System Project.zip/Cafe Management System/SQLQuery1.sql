CREATE TABLE UsersF
(
     ID INT IDENTITY(1,1) PRIMARY KEY,
    User_Name VARCHAR(100) NOT NULL,
    Phone VARCHAR(20) NOT NULL,
    Password VARCHAR(100) NOT NULL
);
select *from UsersF


CREATE TABLE Items
(
    Itemnum INT PRIMARY KEY,
    Item_name VARCHAR(100) NOT NULL,
    Catagory VARCHAR(100) NOT NULL,
    Item_price DECIMAL(10,2) NOT NULL
);
ALTER TABLE Items ADD ItemImage VARBINARY(MAX) NULL;
Select * from Items





CREATE TABLE Orders
(
    OrderNum INT IDENTITY(1,1) PRIMARY KEY,
    
    SellerName VARCHAR(100) NOT NULL,
    CustomerName VARCHAR(100) NOT NULL,
    Time DATETIME NOT NULL,
    TotalAmount DECIMAL(10,2) NOT NULL
);
ALTER TABLE Orders ADD Status NVARCHAR(20) NOT NULL DEFAULT 'Unpaid';

DROP TABLE OrderDetails

Select * from Orders





CREATE TABLE OrderDetails (
    
    OrderNum INT NOT NULL,
    ItemName NVARCHAR(100),
    Category NVARCHAR(100),
    Quantity INT,
    UnitPrice DECIMAL(10,2),
    TotalAmount DECIMAL(10,2)
);
select * from OrderDetails
